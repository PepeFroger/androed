package ru.muctr.composeui_2026

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.muctr.composeui_2026.ui.theme.ComposeUI_2026Theme
import ru.muctr.composeui_2026.ui.theme.LanguageLogo
import ru.muctr.composeui_2026.ui.theme.MyButton

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ComposeUI_2026Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .padding(innerPadding)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        UpperImage()
                        MiddlePart()
                        Spacer(Modifier.height(10.dp))
                        Languagelogos()
                        Spacer(Modifier.height(20.dp))
                        Buttons()
                    }
                }
            }
        }
    }
}

@Composable
fun UpperImage(){
    Image(
        painter = painterResource(R.drawable.muctr),
        contentDescription = "MUCTR University",
        modifier = Modifier.padding(5.dp)
//            .size(800.dp)
    )
}

@Composable
private fun MiddlePart(){
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ){
        Column(
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.title),
                fontSize = 30.sp
            )
            Row{
                Text(text = stringResource(R.string.leader_logo))
                Text(text = stringResource(R.string.leader))
            }
        }
        Image(
            painter = painterResource(R.drawable.muctrlogo),
            contentDescription = "MUCTR logo",
            modifier = Modifier.clip(CircleShape)
        )
    }

    Spacer(Modifier.height(10.dp))
    Text(
        text = stringResource(R.string.description),
        modifier = Modifier.padding(15.dp)
    )
}

@Composable
private fun Languagelogos(){
    Row(
        horizontalArrangement = Arrangement.SpaceBetween
    ){
        LanguageLogo(R.drawable.java, "Java")
        LanguageLogo(R.drawable.python, "Python")
        LanguageLogo(R.drawable.clojur, "Clojure")
    }

    Row{
        LanguageLogo(R.drawable.asm, "Assembler")
        LanguageLogo(R.drawable.csharp, "C#")
    }
}
@Composable
fun Buttons(){
    Row{
        MyButton(R.string.button1)
        MyButton(R.string.button2)
        MyButton(R.string.button3)
    }
}

