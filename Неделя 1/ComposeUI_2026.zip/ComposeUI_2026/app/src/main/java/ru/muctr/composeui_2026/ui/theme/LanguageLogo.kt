package ru.muctr.composeui_2026.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun LanguageLogo(imageId: Int, imageDescription: String){
    Image(
        painter = painterResource(imageId),
        contentDescription = imageDescription,
        modifier = Modifier
            .height(60.dp)
            .padding(10.dp)

    )
}