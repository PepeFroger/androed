package ru.muctr.composeui_2026.ui.theme

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

@Composable
fun MyButton(stringId: Int){
    Button(
        onClick = {},
        colors = ButtonDefaults.buttonColors(
            contentColor = Color(0xffFFFFFF),
            containerColor = Color(0xff483D8B)),
        modifier = Modifier
            .padding(3.dp)
    ) {
        Text(stringResource(stringId))
    }
}